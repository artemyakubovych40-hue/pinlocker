package com.example.pinlocker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val APP_PIN = "1223011"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LockerApp() }
    }
}

@Composable
private fun LockerApp() {
    var pin by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }

    val bg = Color(0xFF101116)
    val panel = Color(0xFF1B1D26)
    val accent = Color(0xFF7C8CFF)
    val muted = Color(0xFF9295A5)

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = bg
        ) {
            if (unlocked) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("ДОСТУП ОТКРЫТ", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("Добро пожаловать!", color = muted, fontSize = 16.sp)
                    Spacer(Modifier.height(32.dp))
                    Button(
                        onClick = { pin = ""; error = false; unlocked = false },
                        colors = ButtonDefaults.buttonColors(containerColor = accent)
                    ) {
                        Text("Заблокировать", color = Color(0xFF101116))
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier.size(68.dp).background(panel, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("●", color = accent, fontSize = 28.sp)
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("PIN LOCKER", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Введите пароль для продолжения", color = muted, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(28.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        repeat(7) { index ->
                            Box(
                                modifier = Modifier.size(13.dp).background(
                                    if (index < pin.length) accent else Color(0xFF454856),
                                    CircleShape
                                )
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        if (error) "Неверный пароль" else " ",
                        color = Color(0xFFFF6B75),
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(18.dp))

                    val keys = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("⌫", "0", "✓")
                    )
                    keys.forEach { line ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            line.forEach { key ->
                                val isAction = key == "⌫" || key == "✓"
                                Button(
                                    onClick = {
                                        when (key) {
                                            "⌫" -> {
                                                if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                                error = false
                                            }
                                            "✓" -> {
                                                if (pin == APP_PIN) {
                                                    unlocked = true
                                                    error = false
                                                } else {
                                                    error = true
                                                    pin = ""
                                                }
                                            }
                                            else -> if (pin.length < 7) {
                                                pin += key
                                                error = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f).height(62.dp),
                                    shape = RoundedCornerShape(18.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isAction) panel else Color(0xFF242733)
                                    )
                                ) {
                                    Text(
                                        key,
                                        color = if (key == "✓") accent else Color.White,
                                        fontSize = 23.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("PIN состоит из 7 цифр", color = muted, fontSize = 12.sp)
                }
            }
        }
    }
}
